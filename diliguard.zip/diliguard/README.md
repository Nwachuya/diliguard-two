# Diliguard

Due diligence search platform built with Next.js 15 and PocketBase.

## Project Structure

```
diliguard/
├── public/               # Static assets
├── src/
│   ├── app/             # Next.js 15 App Router
│   │   ├── (auth)/      # Auth pages (login, register)
│   │   ├── dashboard/   # Main dashboard
│   │   ├── search/      # Search pages (new, details)
│   │   ├── account/     # Account settings
│   │   ├── billing/     # Billing & payments
│   │   ├── feedback/    # Feedback form
│   │   ├── choose-plan/ # Subscription plans
│   │   ├── checkout/    # Stripe checkout
│   │   ├── admin/       # Admin panel
│   │   ├── privacy/     # Privacy policy
│   │   ├── terms/       # Terms of service
│   │   └── api/         # API routes
│   ├── components/      # React components
│   ├── lib/            # Utilities (PocketBase, Stripe)
│   ├── types.ts        # TypeScript types
│   └── middleware.ts   # Route protection
├── .env.example        # Environment variables template
└── package.json        # Dependencies
```

## Setup

1. Install dependencies:
   ```bash
   pnpm install
   ```

2. Copy `.env.example` to `.env.local` and fill in your values:
   ```env
   NEXT_PUBLIC_POCKETBASE_URL=https://diliguarddb.canvass.africa
   NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```

3. Install shadcn/ui:
   ```bash
   npx shadcn@latest init
   npx shadcn@latest add https://tweakcn.com/r/themes/supabase.json
   ```

4. Run development server:
   ```bash
   pnpm dev
   ```

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Database**: PocketBase
- **Payments**: Stripe
- **Deployment**: Vercel

## Pages

- `/` - Home/Landing
- `/login` - Login
- `/register` - Register
- `/dashboard` - Main dashboard
- `/search/new` - New search form
- `/search/[id]` - Search details
- `/account` - Account settings
- `/billing` - Billing & payments
- `/feedback` - Feedback form
- `/choose-plan` - Choose subscription plan
- `/checkout` - Stripe checkout
- `/admin` - Admin dashboard
- `/admin/users` - User management
- `/admin/searches` - Search management
- `/privacy` - Privacy policy
- `/terms` - Terms of service
